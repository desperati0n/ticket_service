# IT 工单 Skill + MCP 客户端使用包

本压缩包只包含 Agent 使用已经部署好的 IT 工单 MCP 所需的客户端文件，不包含服务器、Redis、Worker、数据库或 Docker 源码。

## 包含内容

- `skill/it-ticket-operations/`：可安装的 Skill。
- `examples/connection.example.json`：通用 MCP 连接参数示例。
- `examples/codex-config.example.toml`：Codex 配置示例。
- `examples/token.example.env`：客户端 Token 环境变量示例。

## 使用前准备

向服务管理员取得两项信息：

1. MCP 地址，例如 `https://tickets.example.com/mcp`。只有 MCP 与 Agent 在同一台电脑时才使用 `http://127.0.0.1:8000/mcp`。
2. Bearer Token。不要把 Token 写进 Skill、聊天消息、Git 仓库或普通配置文件。

## 在 Codex 中安装

把整个 `skill/it-ticket-operations` 文件夹复制到当前用户的 Codex Skill 目录：

```text
C:\Users\你的用户名\.codex\skills\it-ticket-operations
```

PowerShell 7 中持久保存 Token：

```powershell
$ticketMcpToken = Read-Host "请输入 MCP Token" -MaskInput
[Environment]::SetEnvironmentVariable("TICKET_MCP_TOKEN", $ticketMcpToken, "User")
```

添加 MCP：

```powershell
codex mcp add it-ticket-service `
  --url https://你的MCP地址/mcp `
  --bearer-token-env-var TICKET_MCP_TOKEN
```

如果服务端没有启用鉴权，省略 `--bearer-token-env-var`。完成后完全退出并重新打开 Codex。

## 在其他 Agent 中使用

不同 Agent 的配置界面和 JSON 格式不完全相同，但需要提供的连接信息一致：

- 传输：Streamable HTTP
- URL：MCP 服务的 `/mcp` 地址
- 鉴权：`Authorization: Bearer <token>`
- 指令：加载 `skill/it-ticket-operations/SKILL.md`

把 Token 存进该 Agent 平台提供的 Secret、Credential 或 Environment Variable 功能，不要直接粘贴到系统提示词。

## 验证

连接后可以先执行只读测试：

```text
查询工号 10008 的员工信息
```

然后测试工单查询：

```text
查询工单 11112848148140032
```

创建工单成功时应返回 `data.ticket_id`。这是之后查询、修改和删除所使用的业务 ID；不要把内部队列标识当作工单 ID。

## 安全边界

- 把 Token 当作密码处理。
- 远程 MCP 必须使用 HTTPS。
- Token 泄露后由服务管理员轮换，客户端同步更新环境变量。
- 当前共享 Bearer Token 适合内部使用；多人细粒度权限建议使用 OAuth/OIDC。
